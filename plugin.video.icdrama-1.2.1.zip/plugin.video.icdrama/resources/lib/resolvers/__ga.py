from resources.lib import ga

class GA(object):
    def ga_track(self, action, label=None):
        ga.event('URL resolution', '%s %s' % (self.name, action), label)
